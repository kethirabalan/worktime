import React, { useState, useEffect, useRef } from 'react';
import { Send, Search, Edit, Paperclip, Smile, MoreHorizontal, Phone, Archive, User } from 'lucide-react';
import { db, auth } from '../lib/firebase';
import { collection, query, orderBy, limit, onSnapshot, addDoc } from 'firebase/firestore';
import { Message } from '../types';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface ChatProps {
  workspaceId: string;
}

export default function Chat({ workspaceId }: ChatProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!workspaceId) return;
    const q = query(
      collection(db, 'workspaces', workspaceId, 'messages'),
      orderBy('timestamp', 'asc'),
      limit(50)
    );

    return onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Message[];
      setMessages(msgs);
    });
  }, [workspaceId]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !auth.currentUser) return;

    try {
      await addDoc(collection(db, 'workspaces', workspaceId, 'messages'), {
        workspaceId,
        senderId: auth.currentUser.uid,
        senderName: auth.currentUser.displayName || 'Anonymous',
        content: newMessage,
        timestamp: new Date().toISOString()
      });
      setNewMessage('');
    } catch (e) {
      console.error("Error sending message", e);
    }
  };

  const mockConversations = [
    { id: '1', name: 'Global Team Chat', handle: '@team', time: 'Just now', msg: 'Sure thing, I\'ll have a look today...', active: true, avatar: 'https://i.pravatar.cc/150?img=1' },
    { id: '2', name: 'Phoenix Baker', handle: '@phoenix', time: '5min ago', msg: 'Hey Olivia, Katherine sent me over...', active: false, avatar: 'https://i.pravatar.cc/150?img=11', unread: true },
    { id: '3', name: 'Katherine Moss', handle: '@kathy', time: '20min ago', msg: 'You: Sure thing, I\'ll have a look today.', active: false, avatar: 'https://i.pravatar.cc/150?img=5' },
    { id: '4', name: 'Mollie Hall', handle: '@mollie', time: '1hr ago', msg: 'I\'ve just published the site again.', active: false, avatar: 'https://i.pravatar.cc/150?img=9', unread: true },
    { id: '5', name: 'Rosalee Melvin', handle: '@rosalee', time: '2hr ago', msg: 'Hey Liv - just wanted to say thanks for...', active: false, avatar: 'https://i.pravatar.cc/150?img=20' },
    { id: '6', name: 'Anaiah Whitten', handle: '@anaiah', time: '2hr ago', msg: 'Good news!! Jack accepted the offer.', active: false, avatar: 'https://i.pravatar.cc/150?img=32' },
  ];

  const formatTime = (isoString: string) => {
    const d = new Date(isoString);
    return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }).toLowerCase();
  };

  return (
    <div className="flex-1 flex h-full bg-[#f9fafc] text-slate-800 font-sans">
      
      {/* Middle Column: Conversations List */}
      <div className="w-[360px] bg-white border-r border-slate-200 flex flex-col shrink-0">
        
        {/* Header */}
        <div className="p-6 pb-4">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <h2 className="text-2xl font-bold text-slate-900">Messages</h2>
              <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 text-xs font-bold border border-slate-200">40</span>
            </div>
            <button className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center text-slate-600 hover:bg-slate-100 transition-colors">
              <Edit className="w-5 h-5" />
            </button>
          </div>
          
          {/* Search */}
          <div className="relative">
            <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search" 
              className="w-full pl-10 pr-4 py-3 rounded-xl bg-white border border-slate-200 text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-shadow"
            />
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto custom-scrollbar">
          {mockConversations.map((conv) => (
            <div 
              key={conv.id} 
              className={cn(
                "p-4 mx-2 rounded-2xl cursor-pointer transition-colors relative mb-1",
                conv.active ? "bg-[#fff1f4]" : "hover:bg-slate-50"
              )}
            >
              {conv.unread && <div className="absolute left-1 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-[#ea1c57]" />}
              <div className="flex items-start gap-4 ml-2">
                <div className="relative shrink-0">
                  <img src={conv.avatar} alt={conv.name} className="w-12 h-12 rounded-full object-cover" />
                  {conv.active && <div className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-green-500 border-2 border-white rounded-full" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-baseline mb-0.5">
                    <h4 className="font-bold text-slate-900 truncate text-sm">{conv.name}</h4>
                    <span className="text-xs text-slate-500 font-medium shrink-0">{conv.time}</span>
                  </div>
                  <p className="text-xs text-slate-500 mb-1">{conv.handle}</p>
                  <p className="text-sm text-slate-600 truncate">{conv.msg}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Right Column: Active Chat */}
      <div className="flex-1 flex flex-col min-w-0 bg-white">
        
        {/* Chat Header */}
        <header className="h-24 px-8 border-b border-slate-200 flex items-center justify-between bg-white shrink-0">
          <div className="flex items-center gap-4">
            <div className="relative">
              <img src="https://i.pravatar.cc/150?img=1" alt="Global" className="w-12 h-12 rounded-full object-cover" />
              <div className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-green-500 border-2 border-white rounded-full" />
            </div>
            <div>
              <div className="flex items-center gap-3">
                <h2 className="text-lg font-bold text-slate-900">Global Team Chat</h2>
                <span className="px-2 py-0.5 rounded-full bg-green-50 border border-green-200 text-green-700 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-500" /> Online
                </span>
              </div>
              <p className="text-sm text-slate-500">@team</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <button className="px-4 py-2.5 rounded-xl border border-red-200 text-[#ea1c57] font-bold text-sm flex items-center gap-2 hover:bg-red-50 transition-colors">
              <Phone className="w-4 h-4" /> Call
            </button>
            <button className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 font-bold text-sm hover:bg-slate-50 transition-colors">
              Archive
            </button>
            <button className="px-4 py-2.5 rounded-xl bg-[#ea1c57] text-white font-bold text-sm hover:bg-[#d6184e] transition-colors shadow-sm shadow-red-500/20">
              View profile
            </button>
            <button className="w-10 h-10 rounded-xl flex items-center justify-center text-slate-400 hover:bg-slate-50 transition-colors ml-1">
              <MoreHorizontal className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Chat Messages */}
        <div ref={scrollRef} className="flex-1 p-8 overflow-y-auto custom-scrollbar flex flex-col gap-6 relative">
          
          <div className="flex justify-center mb-4">
            <span className="px-4 py-1 rounded-full bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-500">Today</span>
          </div>

          <AnimatePresence>
            {messages.map((m) => {
              const isMe = m.senderId === auth.currentUser?.uid;
              
              if (isMe) {
                return (
                  <motion.div key={m.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col items-end gap-1">
                    <div className="flex items-center gap-2 mb-1 mr-1">
                      <span className="font-bold text-sm text-slate-900">You</span>
                      <span className="text-xs text-slate-400">{formatTime(m.timestamp)}</span>
                    </div>
                    <div className="bg-[#111118] text-white px-5 py-3.5 rounded-2xl rounded-tr-sm max-w-lg shadow-sm">
                      <p className="text-[15px] leading-relaxed">{m.content}</p>
                    </div>
                  </motion.div>
                );
              }

              return (
                <motion.div key={m.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex gap-4 max-w-2xl">
                  <img src={`https://i.pravatar.cc/150?u=${m.senderId}`} className="w-10 h-10 rounded-full object-cover shrink-0 mt-1" alt={m.senderName} />
                  <div className="flex flex-col items-start gap-1">
                    <div className="flex items-center gap-2 mb-1 ml-1">
                      <span className="font-bold text-sm text-slate-900">{m.senderName}</span>
                      <span className="text-xs text-slate-400">{formatTime(m.timestamp)}</span>
                    </div>
                    <div className="bg-white border border-slate-200 px-5 py-3.5 rounded-2xl rounded-tl-sm shadow-sm">
                      <p className="text-[15px] text-slate-700 leading-relaxed">{m.content}</p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>

        {/* Input Area */}
        <div className="p-6 bg-white border-t border-slate-100">
          <form onSubmit={sendMessage} className="relative flex items-center">
            <div className="w-full flex items-center border border-slate-200 rounded-2xl bg-white shadow-sm focus-within:border-[#ea1c57] focus-within:ring-1 focus-within:ring-[#ea1c57]/20 transition-all p-2">
              <input 
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Send a message"
                className="flex-1 bg-transparent border-none outline-none text-[15px] text-slate-800 px-4 py-2"
              />
              <div className="flex items-center gap-1 pr-2">
                <button type="button" className="p-2 text-slate-400 hover:text-slate-600 transition-colors"><Smile className="w-5 h-5" /></button>
                <button type="button" className="p-2 text-slate-400 hover:text-slate-600 transition-colors mr-2"><MoreHorizontal className="w-5 h-5" /></button>
                <button 
                  type="submit"
                  disabled={!newMessage.trim()}
                  className="bg-[#ea1c57] hover:bg-[#d6184e] disabled:opacity-50 text-white font-bold px-6 py-2.5 rounded-xl transition-colors shadow-sm flex items-center gap-2"
                >
                  Send
                </button>
              </div>
            </div>
          </form>
        </div>

      </div>
    </div>
  );
}
