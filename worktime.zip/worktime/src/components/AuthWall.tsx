import React, { useState, useEffect } from 'react';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { auth, signInAnonymously, signInWithGoogle, signInWithGithub, db } from '../lib/firebase';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { Loader2, ArrowRight, Zap, Shield, Users, User, Layers, MessageSquare, Layout, Sparkles, X, Github, Mic, Video, PhoneOff, Check, CheckCircle, MousePointer2, ChevronDown } from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface AuthWallProps {
  children: React.ReactNode;
}

export default function AuthWall({ children }: AuthWallProps) {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  useEffect(() => {
    return onAuthStateChanged(auth, async (u) => {
      if (u) {
        // Sync user to Firestore
        const userRef = doc(db, 'users', u.uid);
        const userSnap = await getDoc(userRef);
        if (!userSnap.exists()) {
          await setDoc(userRef, {
            uid: u.uid,
            displayName: u.displayName || 'Guest User',
            email: u.email,
            photoURL: u.photoURL,
            isAnonymous: u.isAnonymous,
            createdAt: new Date().toISOString(),
            lastActive: new Date().toISOString(),
          });
        } else {
          await setDoc(userRef, { lastActive: new Date().toISOString() }, { merge: true });
        }
        setUser(u);
      } else {
        setUser(null);
      }
      setLoading(false);
      setIsLoggingIn(false);
      setShowLoginModal(false);
    });
  }, []);

  const handleLogin = async (provider: 'guest' | 'google' | 'github') => {
    setIsLoggingIn(true);
    try {
      if (provider === 'guest') await signInAnonymously();
      else if (provider === 'google') await signInWithGoogle();
      else if (provider === 'github') await signInWithGithub();
    } catch (err) {
      console.error(`Failed to sign in with ${provider}`, err);
      setIsLoggingIn(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-[#070514] text-white selection:bg-[#cbfb45]/30 font-sans overflow-x-hidden relative">
        {/* iOS Liquid Background Blobs - Aurora Style */}
        <div className="fixed top-[-10%] left-[-10%] w-[60vw] h-[60vw] bg-[#5a2e98]/40 rounded-full mix-blend-screen filter blur-[120px] pointer-events-none" />
        <div className="fixed top-[10%] right-[-10%] w-[50vw] h-[50vw] bg-[#e63946]/30 rounded-full mix-blend-screen filter blur-[150px] pointer-events-none" />
        <div className="fixed bottom-[-10%] left-[20%] w-[50vw] h-[50vw] bg-[#fca311]/20 rounded-full mix-blend-screen filter blur-[140px] pointer-events-none" />
        <div className="fixed bottom-[-20%] right-[10%] w-[60vw] h-[60vw] bg-[#118ab2]/30 rounded-full mix-blend-screen filter blur-[160px] pointer-events-none" />

        {/* Header Navigation */}
        <header className="fixed top-0 w-full z-50">
          <div className="mx-auto max-w-7xl px-6 py-6 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="font-bold text-2xl tracking-tight">WorkTime<span className="text-[#cbfb45]">.</span></span>
            </div>
            
            <nav className="hidden md:flex items-center gap-2 bg-white/5 border border-white/10 backdrop-blur-md rounded-full px-2 py-1.5 text-sm font-medium">
              <a href="#home" className="px-4 py-1.5 bg-white text-black rounded-full transition-colors">Home</a>
              <a href="#about" className="px-4 py-1.5 text-white/70 hover:text-white transition-colors">About</a>
              <a href="#features" className="px-4 py-1.5 text-white/70 hover:text-white transition-colors">Features</a>
              <a href="#pricing" className="px-4 py-1.5 text-white/70 hover:text-white transition-colors">Pricing</a>
            </nav>

            <div>
              <button 
                onClick={() => setShowLoginModal(true)}
                className="group inline-flex items-center justify-center gap-2 px-6 py-2.5 text-sm font-bold text-black bg-white rounded-full hover:scale-105 transition-transform"
              >
                <span>Download Now</span>
              </button>
            </div>
          </div>
        </header>

        {/* Hero Section - Image Replicated */}
        <section id="home" className="relative pt-40 pb-20 px-6 z-10 flex flex-col items-center text-center min-h-[85vh] justify-center">
          
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="max-w-5xl mx-auto relative w-full"
          >
            {/* Left Floating Widget (Video Call) */}
            <motion.div 
              initial={{ opacity: 0, x: -50, rotate: -5 }}
              animate={{ opacity: 1, x: 0, rotate: -5 }}
              transition={{ delay: 0.3, duration: 1 }}
              className="hidden lg:flex absolute left-[-40px] xl:left-[-160px] 2xl:left-[-220px] top-[5%] xl:top-[10%] flex-col gap-2 z-20 hover:rotate-0 transition-transform cursor-pointer scale-75 xl:scale-100 origin-top-left"
            >
              <div className="bg-[#1b1b29] border border-white/10 p-4 rounded-3xl shadow-2xl flex flex-col gap-4 min-w-[240px]">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img src="https://i.pravatar.cc/150?img=11" className="w-8 h-8 rounded-full border border-white/20" alt="Joe" />
                    <span className="font-semibold text-sm">Joe Kingston</span>
                  </div>
                  <span className="bg-[#cbfb45] text-black text-xs font-bold px-2.5 py-1 rounded-full">11:50</span>
                </div>
                <div className="flex justify-center gap-3">
                  <button className="w-10 h-10 rounded-full bg-white text-black flex items-center justify-center hover:scale-110 transition-transform"><Mic className="w-4 h-4" /></button>
                  <button className="w-10 h-10 rounded-full bg-red-500 text-white flex items-center justify-center hover:scale-110 transition-transform"><PhoneOff className="w-4 h-4" /></button>
                  <button className="w-10 h-10 rounded-full bg-[#2a2a3c] text-white flex items-center justify-center hover:scale-110 transition-transform"><Video className="w-4 h-4" /></button>
                </div>
              </div>
              <div className="relative">
                <MousePointer2 className="w-6 h-6 text-orange-400 absolute left-8 top-[-10px] -rotate-12 drop-shadow-md z-30" fill="#fb923c" />
                <div className="bg-orange-400 text-black text-xs font-bold px-3 py-1 rounded-full w-max mt-4 ml-6 relative z-20">Ann Designer</div>
              </div>
            </motion.div>

            {/* Right Floating Widget (Checklist) */}
            <motion.div 
              initial={{ opacity: 0, x: 50, rotate: 3 }}
              animate={{ opacity: 1, x: 0, rotate: 3 }}
              transition={{ delay: 0.5, duration: 1 }}
              className="hidden lg:flex absolute right-[-20px] xl:right-[-120px] 2xl:right-[-180px] top-[20%] xl:top-[25%] flex-col gap-2 z-20 hover:rotate-0 transition-transform cursor-pointer scale-75 xl:scale-100 origin-top-right"
            >
              <div className="bg-white/10 border border-white/20 backdrop-blur-2xl p-5 rounded-3xl shadow-2xl min-w-[280px]">
                <div className="flex items-center justify-between mb-4">
                  <span className="font-semibold text-sm">Checklist</span>
                  <span className="text-xs text-white/50 hover:text-white cursor-pointer">+ Add Subtask</span>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full bg-blue-500 flex items-center justify-center"><Check className="w-3 h-3 text-white" /></div>
                    <span className="text-xs text-white/90">Conduct testing of current user paths.</span>
                  </div>
                  <div className="flex items-center gap-3 opacity-60">
                    <div className="w-5 h-5 rounded-full border border-white/30 flex items-center justify-center"></div>
                    <span className="text-xs text-white/90">Study functionality and UX of similar apps.</span>
                  </div>
                </div>
              </div>
              <div className="relative flex justify-end">
                <MousePointer2 className="w-6 h-6 text-[#cbfb45] absolute right-32 top-[-15px] -rotate-12 drop-shadow-md z-30" fill="#cbfb45" />
                <div className="bg-[#cbfb45] text-black text-xs font-bold px-3 py-1 rounded-full w-max mt-2 mr-6 relative z-20">Jeremy Developer</div>
              </div>
            </motion.div>

            {/* Main Headline */}
            <div className="max-w-4xl mx-auto">
              <h1 className="text-5xl md:text-7xl lg:text-[5.5rem] font-medium tracking-tight leading-[1.1] mb-8 relative z-10">
                Your 
                <span className="inline-flex items-center align-middle mx-4 bg-white/10 p-1.5 rounded-full border border-white/20 backdrop-blur-md shadow-2xl relative">
                  <img src="https://i.pravatar.cc/100?img=1" className="w-10 h-10 md:w-12 md:h-12 rounded-full border border-white/20 relative z-10" alt="Avatar" />
                  <img src="https://i.pravatar.cc/100?img=5" className="w-10 h-10 md:w-12 md:h-12 rounded-full border border-white/20 -ml-4 relative z-20" alt="Avatar" />
                  <img src="https://i.pravatar.cc/100?img=8" className="w-10 h-10 md:w-12 md:h-12 rounded-full border border-white/20 -ml-4 relative z-30" alt="Avatar" />
                  <span className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-[#cbfb45] text-black flex items-center justify-center text-xs md:text-sm font-bold -ml-4 relative z-40 border border-[#cbfb45]">+2k</span>
                </span> 
                capabilities<br/>
                for empower team<br/>
                with <span className="italic">WorkTime!</span>
              </h1>
              
              <p className="text-sm md:text-base text-white/70 max-w-2xl mx-auto mb-10 font-light leading-relaxed">
                Join the ranks of teams who've transformed their productivity, improved communication, and exceeded their project goals. It's time to make every project a success story with WorkTime.
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-4">
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowLoginModal(true)}
                className="px-8 py-3.5 text-sm md:text-base font-bold bg-[#cbfb45] text-black rounded-full hover:bg-[#b5e533] transition-colors"
              >
                Try a Demo
              </motion.button>
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowLoginModal(true)}
                className="px-8 py-3.5 text-sm md:text-base font-bold bg-white/10 text-white border border-white/10 backdrop-blur-md rounded-full hover:bg-white/20 transition-colors"
              >
                View Showreel
              </motion.button>
            </div>
            
          </motion.div>
        </section>

        {/* Fake Integration Logos */}
        <section className="py-10 border-t border-white/10 bg-white/5 backdrop-blur-md relative z-10 mt-10">
          <div className="max-w-6xl mx-auto px-6 flex flex-wrap justify-center md:justify-between items-center gap-8 opacity-60">
             <div className="flex items-center gap-2 text-xl font-bold tracking-tighter"><span className="text-2xl">⬡</span> ClickUp</div>
             <div className="flex items-center gap-2 text-xl font-bold tracking-tighter"><span className="text-2xl">●●●</span> asana</div>
             <div className="flex items-center gap-2 text-xl font-bold tracking-tighter"><Video className="w-6 h-6"/> Google Meet</div>
             <div className="flex items-center gap-2 text-xl font-bold tracking-tighter"><span className="text-2xl">W</span> Webflow</div>
             <div className="flex items-center gap-2 text-xl font-bold tracking-tighter"><Layout className="w-5 h-5"/> Microsoft</div>
             <div className="flex items-center gap-2 text-xl font-bold tracking-tighter">Upwork</div>
          </div>
        </section>

        {/* Pricing Section (UI Graph Style) */}
        <section id="pricing" className={cn(
          "py-32 px-6 relative z-10 transition-colors duration-500 overflow-hidden",
          theme === 'dark' ? "bg-[#070514] text-white" : "bg-white text-slate-900"
        )}>
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <h2 className={cn("text-4xl md:text-6xl font-bold tracking-tight mb-6", theme === 'dark' ? "text-white" : "text-black")}>Our Pricing</h2>
              <p className={cn("max-w-2xl mx-auto text-lg leading-relaxed", theme === 'dark' ? "text-slate-400" : "text-slate-500")}>
                Choose a plan that fits your workflow—solo or team. Simple, flexible pricing with no hidden fees.
              </p>
            </div>

            {/* Toggle Switch */}
            <div className="flex justify-center mb-16">
              <div className={cn("p-1.5 rounded-2xl flex items-center shadow-inner border transition-colors", theme === 'dark' ? "bg-white/5 border-white/10" : "bg-slate-100 border-slate-200")}>
                <button className={cn("px-6 py-2.5 rounded-xl text-sm font-bold shadow-sm flex items-center gap-2", theme === 'dark' ? "bg-white/10 text-white" : "bg-white text-black")}>
                  <Users className="w-4 h-4" /> Businesses & Team
                </button>
                <button className="px-6 py-2.5 rounded-xl text-sm font-bold text-slate-500 hover:text-black transition-colors flex items-center gap-2">
                  <User className="w-4 h-4" /> Individuals
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-32">
              {/* Free Plan */}
              <div className={cn(
                "border rounded-[2.5rem] overflow-hidden flex flex-col hover:shadow-2xl transition-all group",
                theme === 'dark' ? "bg-white/5 border-white/10" : "bg-white border-slate-200"
              )}>
                <div className="p-8 pb-0 relative">
                  <div className={cn("absolute top-0 right-0 w-32 h-32 rounded-full blur-3xl opacity-50 -mr-16 -mt-16", theme === 'dark' ? "bg-white/5" : "bg-slate-100")} />
                  <span className={cn("inline-block px-3 py-1 text-[10px] font-bold rounded-lg uppercase tracking-wider mb-6", theme === 'dark' ? "bg-white/10 text-slate-400" : "bg-slate-100 text-slate-500")}>Free</span>
                  <div className="mb-4">
                    <span className="text-4xl font-bold">$0</span>
                    <span className="text-slate-400 text-sm ml-2">/user/month (billed annually)</span>
                  </div>
                  <p className="text-slate-500 text-sm mb-8">Perfect for individuals exploring WorkTime.</p>
                  <button onClick={() => setShowLoginModal(true)} className={cn("w-full py-3.5 rounded-2xl border font-bold text-sm transition-colors mb-8", theme === 'dark' ? "border-white/10 text-slate-400 hover:bg-white/5" : "border-slate-200 text-slate-400 hover:bg-slate-50")}>Current Plan</button>
                </div>
                <div className={cn("p-8 pt-0 flex-1 border-t mt-4", theme === 'dark' ? "border-white/5" : "border-slate-100")}>
                  <ul className="space-y-4 pt-6">
                    {['3 projects', 'Basic UI-to-backend mapping', 'Flow diagram editor', 'Limited exports (PNG/PDF)', 'Figma integration'].map(f => (
                      <li key={f} className="flex items-center gap-3 text-sm text-slate-600">
                        <CheckCircle className={cn("w-4 h-4", theme === 'dark' ? "text-slate-600" : "text-slate-400")} /> {f}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Team Plan */}
              <div className={cn(
                "border rounded-[2.5rem] overflow-hidden flex flex-col hover:shadow-2xl transition-all group relative",
                theme === 'dark' ? "bg-white/5 border-white/10" : "bg-white border-slate-200"
              )}>
                <div className="p-8 pb-0 relative">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-blue-100 rounded-full blur-3xl opacity-50 -mr-16 -mt-16 group-hover:scale-150 transition-transform" />
                  <span className="inline-block px-3 py-1 bg-blue-50 text-blue-500 text-[10px] font-bold rounded-lg uppercase tracking-wider mb-6">Team</span>
                  <div className="mb-4">
                    <span className="text-4xl font-bold">$12</span>
                    <span className="text-slate-400 text-sm ml-2">/user/month (billed annually)</span>
                  </div>
                  <p className="text-slate-500 text-sm mb-8">Ideal for growing teams and startups.</p>
                  <button onClick={() => setShowLoginModal(true)} className={cn("w-full py-3.5 rounded-2xl border font-bold text-sm transition-colors mb-8", theme === 'dark' ? "border-white/10 text-slate-400 hover:bg-white/5" : "border-slate-200 text-slate-500 hover:bg-slate-50")}>Try for Free</button>
                </div>
                <div className={cn("p-8 pt-0 flex-1 border-t mt-4", theme === 'dark' ? "border-white/5" : "border-slate-100")}>
                  <p className={cn("text-xs font-bold uppercase tracking-widest mb-4 pt-6", theme === 'dark' ? "text-white" : "text-slate-900")}>Includes everything in Free, plus:</p>
                  <ul className="space-y-4">
                    {['Unlimited projects', 'Collaboration tools', 'Real-time team editing', 'GitHub & Postman integration', 'Version history'].map(f => (
                      <li key={f} className="flex items-center gap-3 text-sm text-slate-600">
                        <CheckCircle className="w-4 h-4 text-blue-500" /> {f}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Business Plan */}
              <div className={cn(
                "border rounded-[2.5rem] overflow-hidden flex flex-col shadow-xl shadow-blue-500/5 hover:shadow-2xl transition-all group relative",
                theme === 'dark' ? "bg-white/5 border-blue-500/30" : "bg-white border-blue-500/20"
              )}>
                <div className="p-8 pb-0 relative">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-3xl opacity-50 -mr-16 -mt-16 group-hover:scale-150 transition-transform" />
                  <span className="inline-block px-3 py-1 bg-blue-100 text-blue-600 text-[10px] font-bold rounded-lg uppercase tracking-wider mb-6">Business</span>
                  <div className="mb-4">
                    <span className="text-4xl font-bold">$25</span>
                    <span className="text-slate-400 text-sm ml-2">/user/month (billed annually)</span>
                  </div>
                  <p className="text-slate-500 text-sm mb-8">Advanced features for scaling organizations.</p>
                  <button onClick={() => setShowLoginModal(true)} className="w-full py-3.5 rounded-2xl bg-blue-600 text-white font-bold text-sm hover:bg-blue-700 transition-colors mb-8 shadow-lg shadow-blue-600/20">Try for Free</button>
                </div>
                <div className={cn("p-8 pt-0 flex-1 border-t mt-4", theme === 'dark' ? "border-white/5" : "border-slate-100")}>
                   <p className={cn("text-xs font-bold uppercase tracking-widest mb-4 pt-6", theme === 'dark' ? "text-white" : "text-slate-900")}>Everything in Team, plus:</p>
                  <ul className="space-y-4">
                    {['Org-level project control', 'Advanced API integration', 'Custom branding', 'Role-based access control', 'Slack & Notion integration'].map(f => (
                      <li key={f} className="flex items-center gap-3 text-sm text-slate-600">
                        <CheckCircle className="w-4 h-4 text-blue-600" /> {f}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Enterprise Plan */}
              <div className={cn(
                "border rounded-[2.5rem] overflow-hidden flex flex-col hover:shadow-2xl transition-all group relative",
                theme === 'dark' ? "bg-white/5 border-white/10" : "bg-white border-slate-200"
              )}>
                <div className="p-8 pb-0 relative">
                  <div className={cn("absolute top-0 right-0 w-32 h-32 rounded-full blur-3xl opacity-50 -mr-16 -mt-16 group-hover:scale-150 transition-transform", theme === 'dark' ? "bg-indigo-500/5" : "bg-indigo-50")} />
                  <span className={cn("inline-block px-3 py-1 text-[10px] font-bold rounded-lg uppercase tracking-wider mb-6", theme === 'dark' ? "bg-white/10 text-slate-400" : "bg-slate-100 text-slate-500")}>Enterprise</span>
                  <div className="mb-4">
                    <span className="text-4xl font-bold">Custom</span>
                  </div>
                  <p className="text-slate-500 text-sm mb-8">Perfect for Large Organization & Full Access.</p>
                  <button onClick={() => setShowLoginModal(true)} className={cn("w-full py-3.5 rounded-2xl border font-bold text-sm transition-colors mb-8", theme === 'dark' ? "border-white/10 text-slate-400 hover:bg-white/5" : "border-slate-200 text-slate-500 hover:bg-slate-50")}>Contact Us</button>
                </div>
                <div className={cn("p-8 pt-0 flex-1 border-t mt-4", theme === 'dark' ? "border-white/5" : "border-slate-100")}>
                  <p className={cn("text-xs font-bold uppercase tracking-widest mb-4 pt-6", theme === 'dark' ? "text-white" : "text-slate-900")}>Everything in Business, plus:</p>
                  <ul className="space-y-4">
                    {['SSO & SCIM provisioning', 'Audit logs & analytics', 'Dedicated success manager', 'Private cloud or on-prem', 'Custom onboarding'].map(f => (
                      <li key={f} className="flex items-center gap-3 text-sm text-slate-600">
                        <CheckCircle className={cn("w-4 h-4", theme === 'dark' ? "text-slate-600" : "text-slate-400")} /> {f}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* FAQ Section */}
            <div className={cn("max-w-3xl mx-auto pt-20 border-t transition-colors", theme === 'dark' ? "border-white/10" : "border-slate-100")}>
              <h2 className={cn("text-4xl md:text-5xl font-bold tracking-tight mb-16 text-center", theme === 'dark' ? "text-white" : "text-black")}>Frequently asked questions.</h2>
              <div className="space-y-4">
                {[
                  { q: "What payment methods do you accept?", a: "We accept all major credit cards, bank transfers, and invoice-based payments for enterprise plans." },
                  { q: "How is pricing calculated?", a: "Pricing is based on the number of seats (users) in your workspace on a monthly or annual basis." },
                  { q: "What happens when my trial ends?", a: "You'll be moved to the Free plan unless you choose to subscribe to one of our paid plans." },
                  { q: "Who can manage account settings?", a: "Workspace owners and admins have full control over billing and account settings." },
                ].map((faq, i) => (
                  <div key={i} className={cn("rounded-3xl p-8 border transition-all", theme === 'dark' ? "bg-white/5 border-white/10" : "bg-slate-50 border-slate-200")}>
                    <div className="flex items-center justify-between cursor-pointer">
                      <h4 className={cn("font-bold text-lg", theme === 'dark' ? "text-white" : "text-slate-900")}>{faq.q}</h4>
                      <ChevronDown className={cn("w-5 h-5 text-slate-400 transition-transform", i === 0 && "rotate-180")} />
                    </div>
                    {i === 0 && (
                      <div className={cn("mt-4 text-sm leading-relaxed", theme === 'dark' ? "text-slate-400" : "text-slate-500")}>
                        {faq.a} <a href="#" className="text-blue-600 font-semibold hover:underline">Contact us</a> if you need custom billing support.
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="border-t border-white/10 bg-[#070514] relative z-10">
          <div className="max-w-7xl mx-auto px-6 py-12 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2 opacity-50">
              <span className="font-bold text-sm">WorkTime Inc.</span>
            </div>
            
            <div className="flex gap-8 text-sm font-medium text-neutral-500">
              <a href="#" className="hover:text-white transition-colors">Privacy</a>
              <a href="#" className="hover:text-white transition-colors">Terms</a>
              <a href="#" className="hover:text-white transition-colors">Twitter</a>
            </div>
            
            <div className="text-sm text-neutral-600">
              &copy; 2026 WorkTime. All rights reserved.
            </div>

            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-neutral-500 uppercase tracking-widest">Theme</span>
              <div className="bg-white/5 border border-white/10 p-1 rounded-full flex items-center">
                <button 
                  onClick={() => setTheme('light')}
                  className={cn("w-8 h-8 rounded-full flex items-center justify-center transition-all", theme === 'light' ? "bg-white text-black shadow-lg" : "text-neutral-500 hover:text-white")}
                >
                  <Sparkles className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => setTheme('dark')}
                  className={cn("w-8 h-8 rounded-full flex items-center justify-center transition-all", theme === 'dark' ? "bg-[#cbfb45] text-black shadow-lg" : "text-neutral-500 hover:text-white")}
                >
                  <Zap className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </footer>

        {/* Login Modal */}
        <AnimatePresence>
          {showLoginModal && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowLoginModal(false)}
                className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="relative w-full max-w-md bg-[#131318] border border-white/10 rounded-3xl shadow-2xl p-8 overflow-hidden"
              >
                <button 
                  onClick={() => setShowLoginModal(false)}
                  className="absolute top-6 right-6 text-neutral-500 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>

                <div className="mb-8 text-center">
                  <div className="w-12 h-12 mx-auto rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-purple-500/20 mb-4">
                    <span className="font-bold text-2xl leading-none text-white italic tracking-tighter">W</span>
                  </div>
                  <h3 className="text-2xl font-bold tracking-tight mb-2">Welcome Back</h3>
                  <p className="text-sm text-neutral-400">Choose a method to continue</p>
                </div>

                <div className="flex flex-col gap-3">
                  <button 
                    onClick={() => handleLogin('google')}
                    disabled={isLoggingIn}
                    className="flex items-center justify-center gap-3 w-full bg-white text-black font-semibold rounded-xl px-4 py-3 hover:bg-neutral-200 transition-colors disabled:opacity-50"
                  >
                    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                    </svg>
                    Continue with Google
                  </button>

                  <button 
                    onClick={() => handleLogin('github')}
                    disabled={isLoggingIn}
                    className="flex items-center justify-center gap-3 w-full bg-[#24292e] text-white font-semibold rounded-xl px-4 py-3 hover:bg-[#2c3238] transition-colors disabled:opacity-50"
                  >
                    <Github className="w-5 h-5" />
                    Continue with GitHub
                  </button>

                  <div className="relative my-4">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-white/10"></div>
                    </div>
                    <div className="relative flex justify-center text-xs">
                      <span className="bg-[#131318] px-2 text-neutral-500">Or continue without account</span>
                    </div>
                  </div>

                  <button 
                    onClick={() => handleLogin('guest')}
                    disabled={isLoggingIn}
                    className="flex items-center justify-center gap-3 w-full bg-white/5 border border-white/10 text-white font-semibold rounded-xl px-4 py-3 hover:bg-white/10 transition-colors disabled:opacity-50"
                  >
                    {isLoggingIn ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Proceed as Guest'}
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  return <>{children}</>;
}
