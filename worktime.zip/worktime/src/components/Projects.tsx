import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Search, 
  MoreHorizontal, 
  Folder, 
  Users, 
  Calendar, 
  Trash2, 
  Loader2,
  CheckCircle,
  Layout
} from 'lucide-react';
import { db, auth } from '../lib/firebase';
import { collection, query, onSnapshot, addDoc, deleteDoc, doc, orderBy } from 'firebase/firestore';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface ProjectsProps {
  workspaceId: string;
}

interface Project {
  id: string;
  name: string;
  description: string;
  status: 'active' | 'completed' | 'archived';
  createdAt: string;
  memberCount: number;
  taskCount: number;
}

export default function Projects({ workspaceId }: ProjectsProps) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectDesc, setNewProjectDesc] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  useEffect(() => {
    if (!workspaceId) return;
    const q = query(
      collection(db, 'workspaces', workspaceId, 'projects'),
      orderBy('createdAt', 'desc')
    );

    return onSnapshot(q, (snapshot) => {
      const list = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Project[];
      setProjects(list);
      setLoading(false);
    });
  }, [workspaceId]);

  const handleAddProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjectName.trim() || !workspaceId) return;
    setIsAdding(true);
    try {
      await addDoc(collection(db, 'workspaces', workspaceId, 'projects'), {
        name: newProjectName,
        description: newProjectDesc,
        status: 'active',
        memberCount: 1,
        taskCount: 0,
        createdAt: new Date().toISOString()
      });
      setNewProjectName('');
      setNewProjectDesc('');
      setShowAddModal(false);
    } catch (err) {
      console.error(err);
    } finally {
      setIsAdding(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this project?')) return;
    try {
      await deleteDoc(doc(db, 'workspaces', workspaceId, 'projects', id));
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center bg-[#f9fafc]">
        <Loader2 className="w-8 h-8 animate-spin text-[#ea1c57]" />
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto bg-[#f9fafc] text-slate-800 p-8 lg:p-12 custom-scrollbar">
      <div className="max-w-7xl mx-auto">
        
        <header className="mb-12 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Projects</h1>
            <p className="text-slate-500">Manage and track all your active initiatives.</p>
          </div>
          <div className="flex items-center gap-4">
             <div className="relative hidden sm:block">
               <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
               <input 
                 type="text" 
                 placeholder="Search projects..." 
                 className="pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm outline-none focus:border-[#ea1c57] w-64 transition-all"
               />
             </div>
             <button 
               onClick={() => setShowAddModal(true)}
               className="bg-[#ea1c57] text-white px-6 py-2.5 rounded-xl font-bold text-sm flex items-center gap-2 hover:bg-[#d6184e] transition-colors shadow-lg shadow-red-500/20"
             >
               <Plus className="w-4 h-4" /> New Project
             </button>
          </div>
        </header>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <AnimatePresence>
            {projects.map((project) => (
              <motion.div
                key={project.id}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-white border border-slate-200 rounded-[2.5rem] p-8 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all group flex flex-col"
              >
                <div className="flex items-start justify-between mb-6">
                  <div className="w-14 h-14 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-center text-[#ea1c57] group-hover:scale-110 transition-transform">
                    <Folder className="w-7 h-7" />
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => handleDelete(project.id)} className="p-2 rounded-xl text-slate-300 hover:text-red-500 hover:bg-red-50 transition-all opacity-0 group-hover:opacity-100">
                       <Trash2 className="w-4 h-4" />
                    </button>
                    <button className="p-2 rounded-xl text-slate-300 hover:text-slate-600 hover:bg-slate-50 transition-all">
                       <MoreHorizontal className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                <h3 className="text-xl font-bold text-slate-900 mb-3 group-hover:text-[#ea1c57] transition-colors">{project.name}</h3>
                <p className="text-sm text-slate-500 mb-8 line-clamp-2 flex-1">{project.description || 'No description provided for this project.'}</p>

                <div className="pt-6 border-t border-slate-50 flex items-center justify-between">
                  <div className="flex items-center gap-4 text-slate-400">
                    <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider">
                      <Layout className="w-4 h-4" /> {project.taskCount} Tasks
                    </div>
                    <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider">
                      <Users className="w-4 h-4" /> {project.memberCount}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                     <Calendar className="w-4 h-4 text-slate-300" />
                     <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{new Date(project.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {/* Empty State */}
          {projects.length === 0 && (
            <div className="col-span-full py-20 text-center bg-white border border-dashed border-slate-200 rounded-[3rem]">
              <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6 text-slate-300">
                 <Folder className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">No projects yet</h3>
              <p className="text-slate-500 mb-8 max-w-xs mx-auto">Create your first project to start organizing your team's workflow.</p>
              <button 
                onClick={() => setShowAddModal(true)}
                className="text-[#ea1c57] font-bold hover:underline underline-offset-4"
              >
                + Create project
              </button>
            </div>
          )}
        </div>

        {/* Add Project Modal */}
        <AnimatePresence>
          {showAddModal && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowAddModal(false)}
                className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
              />
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="relative w-full max-w-md bg-white rounded-[2.5rem] p-10 shadow-2xl border border-slate-100"
              >
                <h3 className="text-2xl font-bold text-slate-900 mb-8">Create New Project</h3>
                <form onSubmit={handleAddProject} className="space-y-6">
                  <div>
                    <label className="block text-sm font-bold text-slate-500 mb-3 uppercase tracking-widest">Project Name</label>
                    <input 
                      type="text" 
                      value={newProjectName}
                      onChange={(e) => setNewProjectName(e.target.value)}
                      placeholder="e.g. Website Redesign"
                      className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 text-slate-800 outline-none focus:border-[#ea1c57] transition-all"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-500 mb-3 uppercase tracking-widest">Description</label>
                    <textarea 
                      value={newProjectDesc}
                      onChange={(e) => setNewProjectDesc(e.target.value)}
                      placeholder="What is this project about?"
                      className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 text-slate-800 outline-none focus:border-[#ea1c57] transition-all h-32 resize-none"
                    />
                  </div>
                  <div className="flex gap-4 pt-4">
                    <button 
                      type="button" 
                      onClick={() => setShowAddModal(false)}
                      className="flex-1 py-4 rounded-2xl font-bold text-slate-400 hover:bg-slate-50 transition-colors"
                    >
                      Cancel
                    </button>
                    <button 
                      type="submit"
                      disabled={isAdding || !newProjectName.trim()}
                      className="flex-1 py-4 bg-[#ea1c57] text-white rounded-2xl font-bold shadow-lg shadow-red-500/20 hover:bg-[#d6184e] transition-colors disabled:opacity-50"
                    >
                      {isAdding ? <Loader2 className="w-5 h-5 animate-spin mx-auto" /> : 'Create Project'}
                    </button>
                  </div>
                </form>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
