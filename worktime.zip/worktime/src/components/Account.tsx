import React, { useState } from 'react';
import { auth, db } from '../lib/firebase';
import { updateProfile } from 'firebase/auth';
import { doc, updateDoc } from 'firebase/firestore';
import { User, Mail, Shield, Check, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';

export default function Account() {
  const user = auth.currentUser;
  const [displayName, setDisplayName] = useState(user?.displayName || '');
  const [isSaving, setIsSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setIsSaving(true);
    try {
      await updateProfile(user, { displayName });
      await updateDoc(doc(db, 'users', user.uid), { displayName });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="flex-1 bg-[#0a0a0c] text-white p-8 md:p-12 overflow-y-auto custom-scrollbar">
      <div className="max-w-3xl mx-auto mt-10">
        <h1 className="text-3xl font-bold mb-8 tracking-tight">Account Settings</h1>
        
        <div className="bg-white/5 border border-white/10 rounded-3xl p-8 backdrop-blur-xl mb-8">
          <div className="flex items-center gap-6 mb-8">
            <div className="w-20 h-20 rounded-2xl bg-neutral-800 flex items-center justify-center overflow-hidden border border-white/10">
              {user?.photoURL ? (
                <img src={user.photoURL} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                <User className="w-8 h-8 text-neutral-500" />
              )}
            </div>
            <div>
              <h2 className="text-xl font-bold">{user?.displayName || 'Guest User'}</h2>
              <p className="text-neutral-400 text-sm flex items-center gap-2 mt-1">
                <Mail className="w-4 h-4" />
                {user?.email || 'Anonymous Account'}
              </p>
            </div>
          </div>

          <form onSubmit={handleSave} className="space-y-6 max-w-md">
            <div>
              <label className="block text-sm font-medium text-neutral-400 mb-2">Display Name</label>
              <input 
                type="text" 
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500 transition-colors"
                placeholder="Enter your name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-400 mb-2">User ID</label>
              <div className="w-full bg-black/20 border border-white/5 rounded-xl px-4 py-3 text-neutral-500 font-mono text-sm">
                {user?.uid}
              </div>
            </div>
            
            <button 
              type="submit" 
              disabled={isSaving || displayName === user?.displayName}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-600/50 disabled:cursor-not-allowed text-white px-6 py-3 rounded-xl font-medium transition-colors"
            >
              {isSaving ? <Loader2 className="w-5 h-5 animate-spin" /> : (saved ? <Check className="w-5 h-5" /> : 'Save Changes')}
            </button>
          </form>
        </div>
        
        <div className="bg-white/5 border border-white/10 rounded-3xl p-8 backdrop-blur-xl">
           <h3 className="text-lg font-bold mb-2 flex items-center gap-2">
             <Shield className="w-5 h-5 text-indigo-400" /> Security
           </h3>
           <p className="text-sm text-neutral-400 mb-6">Manage your account security and authentication methods.</p>
           
           <div className="p-4 bg-black/20 border border-white/5 rounded-xl flex items-center justify-between">
             <div>
               <p className="font-medium text-sm">Authentication Method</p>
               <p className="text-xs text-neutral-500 mt-1">{user?.isAnonymous ? 'Guest Login (No persistent credentials)' : (user?.providerData[0]?.providerId || 'Email/Password')}</p>
             </div>
             {user?.isAnonymous && (
               <span className="px-3 py-1 bg-amber-500/10 text-amber-500 text-xs font-bold rounded-lg uppercase tracking-wider">Temporary</span>
             )}
           </div>
        </div>
      </div>
    </div>
  );
}
