import React, { useState, useEffect } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line,
  Cell
} from 'recharts';
import { db } from '../lib/firebase';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { Task } from '../types';
import { 
  TrendingUp, 
  BarChart2, 
  Clock, 
  CheckCircle, 
  PieChart as PieChartIcon, 
  Download,
  Calendar,
  Filter
} from 'lucide-react';
import { motion } from 'motion/react';

interface TimelineProps {
  workspaceId: string;
}

export default function Timeline({ workspaceId }: TimelineProps) {
  const [tasks, setTasks] = useState<Task[]>([]);

  useEffect(() => {
    if (!workspaceId) return;
    const q = query(collection(db, 'workspaces', workspaceId, 'tasks'), orderBy('createdAt', 'desc'));
    return onSnapshot(q, (snapshot) => {
      setTasks(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Task)));
    });
  }, [workspaceId]);

  const stats = [
    { label: 'Completion Rate', value: tasks.length ? `${Math.round((tasks.filter(t => t.status === 'DONE').length / tasks.length) * 100)}%` : '0%', icon: CheckCircle, color: 'text-emerald-500' },
    { label: 'Total Hours', value: '1,248', icon: Clock, color: 'text-blue-500' },
    { label: 'Performance', value: '+18.2%', icon: TrendingUp, color: 'text-[#ea1c57]' },
  ];

  const chartData = [
    { name: 'Week 1', productivity: 65, efficiency: 40 },
    { name: 'Week 2', productivity: 85, efficiency: 60 },
    { name: 'Week 3', productivity: 78, efficiency: 75 },
    { name: 'Week 4', productivity: 95, efficiency: 85 },
  ];

  return (
    <div className="flex-1 overflow-y-auto bg-[#f9fafc] text-slate-800 p-8 lg:p-12 custom-scrollbar">
      <div className="max-w-7xl mx-auto">
        
        <header className="mb-12 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Reporting & Analytics</h1>
            <p className="text-slate-500">Track team productivity and project health in real-time.</p>
          </div>
          <div className="flex items-center gap-3">
             <button className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-600 font-bold text-sm flex items-center gap-2 hover:bg-slate-50 transition-colors">
                <Calendar className="w-4 h-4" /> This Month
             </button>
             <button className="bg-[#ea1c57] text-white px-6 py-2.5 rounded-xl font-bold text-sm flex items-center gap-2 hover:bg-[#d6184e] transition-colors shadow-lg shadow-red-500/20">
                <Download className="w-4 h-4" /> Export Data
             </button>
          </div>
        </header>

        {/* Highlight Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-10">
          {stats.map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white border border-slate-200 rounded-[2.5rem] p-8 shadow-sm"
            >
              <div className="flex items-center gap-4 mb-4">
                 <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center">
                    <stat.icon className={stat.color} />
                 </div>
                 <span className="text-sm font-bold text-slate-400 uppercase tracking-widest">{stat.label}</span>
              </div>
              <p className="text-4xl font-bold text-slate-900">{stat.value}</p>
            </motion.div>
          ))}
        </div>

        {/* Main Analytics Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-10">
          
          <div className="bg-white border border-slate-200 rounded-[3rem] p-10 shadow-sm flex flex-col">
            <div className="flex justify-between items-center mb-10">
               <div>
                  <h3 className="text-xl font-bold text-slate-900">Efficiency Trend</h3>
                  <p className="text-sm text-slate-400">Comparing productivity vs efficiency</p>
               </div>
               <BarChart2 className="w-6 h-6 text-slate-300" />
            </div>
            <div className="flex-1 min-h-[300px]">
               <ResponsiveContainer width="100%" height="100%">
                 <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} dy={10} />
                    <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} />
                    <Tooltip contentStyle={{ borderRadius: '16px', border: '1px solid #f1f5f9' }} />
                    <Line type="monotone" dataKey="productivity" stroke="#ea1c57" strokeWidth={4} dot={{ fill: '#ea1c57', strokeWidth: 2, r: 6 }} activeDot={{ r: 8 }} />
                    <Line type="monotone" dataKey="efficiency" stroke="#3b82f6" strokeWidth={4} dot={{ fill: '#3b82f6', strokeWidth: 2, r: 6 }} activeDot={{ r: 8 }} />
                 </LineChart>
               </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-[3rem] p-10 shadow-sm flex flex-col">
            <div className="flex justify-between items-center mb-10">
               <div>
                  <h3 className="text-xl font-bold text-slate-900">Project Distribution</h3>
                  <p className="text-sm text-slate-400">Total hours spent per category</p>
               </div>
               <PieChartIcon className="w-6 h-6 text-slate-300" />
            </div>
            <div className="flex-1 min-h-[300px]">
               <ResponsiveContainer width="100%" height="100%">
                 <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} dy={10} />
                    <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} />
                    <Tooltip contentStyle={{ borderRadius: '16px', border: '1px solid #f1f5f9' }} />
                    <Bar dataKey="productivity" fill="#ea1c57" radius={[10, 10, 0, 0]} />
                    <Bar dataKey="efficiency" fill="#cbd5e1" radius={[10, 10, 0, 0]} />
                 </BarChart>
               </ResponsiveContainer>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
