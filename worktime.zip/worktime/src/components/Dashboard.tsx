import React, { useState, useEffect } from 'react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { db } from '../lib/firebase';
import { collection, onSnapshot, query, orderBy, limit } from 'firebase/firestore';
import { Task } from '../types';
import { Activity, CheckCircle, Clock, TrendingUp, Zap, Layout, Calendar, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

interface DashboardProps {
  workspaceId: string;
}

const PIE_COLORS = ['#ea1c57', '#3b82f6', '#10b981']; // Red, Blue, Emerald

export default function Dashboard({ workspaceId }: DashboardProps) {
  const [tasks, setTasks] = useState<Task[]>([]);

  useEffect(() => {
    if (!workspaceId) return;
    const q = query(collection(db, 'workspaces', workspaceId, 'tasks'), orderBy('createdAt', 'desc'));
    return onSnapshot(q, (snapshot) => {
      setTasks(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Task)));
    });
  }, [workspaceId]);

  const stats = [
    { label: 'Active Tasks', value: tasks.filter(t => t.status !== 'DONE').length, icon: Activity, color: 'text-blue-500', bg: 'bg-blue-50' },
    { label: 'Completed', value: tasks.filter(t => t.status === 'DONE').length, icon: CheckCircle, color: 'text-emerald-500', bg: 'bg-emerald-50' },
    { label: 'Efficiency', value: '94%', icon: Zap, color: 'text-[#ea1c57]', bg: 'bg-[#ea1c57]/5' },
    { label: 'Team Size', value: '12', icon: Layout, color: 'text-purple-500', bg: 'bg-purple-50' },
  ];

  const activityData = [
    { name: 'Mon', tasks: 3, completed: 1 },
    { name: 'Tue', tasks: 7, completed: 3 },
    { name: 'Wed', tasks: 5, completed: 4 },
    { name: 'Thu', tasks: 8, completed: 6 },
    { name: 'Fri', tasks: 12, completed: 8 },
    { name: 'Sat', tasks: 4, completed: 2 },
    { name: 'Sun', tasks: Math.max(tasks.length, 2), completed: tasks.filter(t => t.status === 'DONE').length },
  ];

  const statusData = [
    { name: 'To Do', value: tasks.filter(t => t.status === 'TODO').length },
    { name: 'In Progress', value: tasks.filter(t => t.status === 'IN_PROGRESS').length },
    { name: 'Done', value: tasks.filter(t => t.status === 'DONE').length },
  ];

  return (
    <div className="flex-1 overflow-y-auto bg-[#f9fafc] text-slate-800 p-8 lg:p-12 custom-scrollbar">
      <div className="max-w-7xl mx-auto">
        <header className="mb-12 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Welcome Back,</h1>
            <p className="text-slate-500">Here's a summary of your workspace performance today.</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="bg-white px-4 py-2 rounded-xl border border-slate-200 flex items-center gap-2 shadow-sm">
              <Calendar className="w-4 h-4 text-slate-400" />
              <span className="text-sm font-medium text-slate-600">May 02, 2026</span>
            </div>
          </div>
        </header>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
          {stats.map((stat, i) => (
            <motion.div 
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm hover:shadow-md transition-all group"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110", stat.bg, stat.color)}>
                  <stat.icon className="w-6 h-6" />
                </div>
                <div className="flex items-center gap-1 text-emerald-500 text-xs font-bold bg-emerald-50 px-2 py-1 rounded-lg">
                  <TrendingUp className="w-3 h-3" /> +12%
                </div>
              </div>
              <div>
                <p className="text-3xl font-bold text-slate-900 mb-1">{stat.value}</p>
                <p className="text-sm font-medium text-slate-400">{stat.label}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-10">
          
          {/* Main Chart */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="lg:col-span-2 bg-white rounded-[2rem] border border-slate-200 p-8 shadow-sm flex flex-col"
          >
            <div className="flex justify-between items-center mb-8">
              <div>
                <h3 className="text-xl font-bold text-slate-900">Task Velocity</h3>
                <p className="text-sm text-slate-400">Activity in the last 7 days</p>
              </div>
              <select className="bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-sm font-medium text-slate-600 outline-none focus:border-[#ea1c57]">
                <option>Weekly View</option>
                <option>Monthly View</option>
              </select>
            </div>
            
            <div className="flex-1 min-h-[350px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={activityData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorTasks" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ea1c57" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#ea1c57" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorCompleted" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '16px', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Area type="monotone" dataKey="tasks" stroke="#ea1c57" strokeWidth={3} fillOpacity={1} fill="url(#colorTasks)" />
                  <Area type="monotone" dataKey="completed" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorCompleted)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          {/* Distribution Donut */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-[2rem] border border-slate-200 p-8 shadow-sm flex flex-col items-center justify-center text-center"
          >
            <h3 className="text-xl font-bold text-slate-900 mb-2">Work Breakdown</h3>
            <p className="text-sm text-slate-400 mb-8">Tasks by current status</p>
            
            <div className="relative w-full h-[250px] flex items-center justify-center mb-8">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusData}
                    cx="50%" cy="50%"
                    innerRadius={70} outerRadius={90}
                    paddingAngle={8}
                    dataKey="value"
                    stroke="none"
                  >
                    {statusData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-4xl font-bold text-slate-900">{tasks.length}</span>
                <span className="text-xs uppercase tracking-widest text-slate-400 font-bold mt-1">Total</span>
              </div>
            </div>

            <div className="w-full space-y-4 text-left">
              {statusData.map((s, i) => (
                <div key={s.name} className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: PIE_COLORS[i] }} />
                    <span className="text-sm font-bold text-slate-700">{s.name}</span>
                  </div>
                  <span className="text-sm font-bold text-slate-900">{s.value}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Recent Activity List */}
        <div className="bg-white rounded-[2rem] border border-slate-200 p-8 shadow-sm">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-xl font-bold text-slate-900">Recent Activity</h3>
            <button className="text-sm font-bold text-[#ea1c57] flex items-center gap-1 hover:underline">View All <ChevronRight className="w-4 h-4" /></button>
          </div>
          <div className="space-y-4">
             {tasks.slice(0, 5).map((task) => (
               <div key={task.id} className="flex items-center justify-between p-4 rounded-2xl hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-100 group">
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center",
                      task.status === 'DONE' ? "bg-emerald-50 text-emerald-500" : "bg-blue-50 text-blue-500"
                    )}>
                       {task.status === 'DONE' ? <CheckCircle className="w-5 h-5" /> : <Clock className="w-5 h-5" />}
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 group-hover:text-[#ea1c57] transition-colors">{task.title}</p>
                      <p className="text-xs text-slate-400 font-medium">Updated {new Date(task.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                     <span className={cn(
                       "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                       task.priority === 'HIGH' ? "bg-red-50 text-red-600" : "bg-slate-100 text-slate-500"
                     )}>
                       {task.priority}
                     </span>
                     <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-slate-500 transition-colors" />
                  </div>
               </div>
             ))}
          </div>
        </div>
      </div>
    </div>
  );
}
