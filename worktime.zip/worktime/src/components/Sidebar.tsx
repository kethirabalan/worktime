import React from 'react';
import { 
  Home,
  LayoutDashboard,
  FolderOpen,
  CheckSquare,
  PieChart,
  MessageSquare,
  Settings,
  HelpCircle,
  LogOut,
  ChevronDown,
  ChevronRight,
  User,
  Zap
} from 'lucide-react';
import { auth } from '../lib/firebase';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  workspaces: any[];
  activeWorkspaceId: string;
  setActiveWorkspaceId: (id: string) => void;
}

export default function Sidebar({ 
  activeTab, 
  setActiveTab, 
}: SidebarProps) {
  const isMessagesExpanded = activeTab === 'chat';

  const mainLinks = [
    { id: 'dashboard', icon: Home, label: 'Home' },
    { id: 'projects', icon: FolderOpen, label: 'Projects' },
    { id: 'tasks', icon: CheckSquare, label: 'Tasks' },
    { id: 'timeline', icon: PieChart, label: 'Reporting' },
  ];

  return (
    <div className="w-64 h-screen bg-[#111118] text-white flex flex-col shrink-0 overflow-y-auto custom-scrollbar border-r border-white/5">
      {/* Brand Logo */}
      <div className="p-6 flex items-center gap-3">
        <div className="w-8 h-8 rounded-full bg-[#ea1c57] flex items-center justify-center">
          <Zap className="w-4 h-4 text-white fill-current" />
        </div>
        <span className="text-xl font-bold tracking-tight">WorkTime</span>
      </div>

      {/* Main Navigation */}
      <nav className="flex-1 px-4 space-y-1 mt-4">
        {mainLinks.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={cn(
              "w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all font-medium text-sm group",
              activeTab === item.id 
                ? "bg-white/10 text-white" 
                : "text-neutral-400 hover:text-white hover:bg-white/5"
            )}
          >
            <div className="flex items-center gap-3">
              <item.icon className={cn("w-5 h-5 transition-colors", activeTab === item.id ? "text-white" : "text-neutral-500 group-hover:text-neutral-300")} />
              <span>{item.label}</span>
            </div>
            <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-50 transition-opacity" />
          </button>
        ))}

        {/* Messages Dropdown */}
        <div className="pt-1">
          <button
            onClick={() => setActiveTab('chat')}
            className={cn(
              "w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all font-medium text-sm group",
              activeTab === 'chat' 
                ? "bg-white/10 text-white" 
                : "text-neutral-400 hover:text-white hover:bg-white/5"
            )}
          >
            <div className="flex items-center gap-3">
              <MessageSquare className={cn("w-5 h-5 transition-colors", isMessagesExpanded ? "text-white" : "text-neutral-500 group-hover:text-neutral-300")} />
              <span>Messages</span>
            </div>
            {isMessagesExpanded ? <ChevronDown className="w-4 h-4 text-neutral-400" /> : <ChevronRight className="w-4 h-4 text-neutral-500 group-hover:opacity-100 opacity-0 transition-opacity" />}
          </button>

          <AnimatePresence>
            {isMessagesExpanded && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden"
              >
                <div className="flex flex-col gap-1 py-2 px-4 ml-2">
                  <button className="text-left px-4 py-2.5 rounded-xl bg-[#ea1c57] text-white text-sm font-medium">
                    View all
                  </button>
                  <button className="text-left px-4 py-2.5 rounded-xl text-neutral-400 hover:text-white hover:bg-white/5 text-sm font-medium transition-colors">
                    Your team
                  </button>
                  <button className="text-left px-4 py-2.5 rounded-xl text-neutral-400 hover:text-white hover:bg-white/5 text-sm font-medium transition-colors">
                    Archived
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </nav>

      {/* Bottom Actions */}
      <div className="p-4 space-y-1">
        <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-neutral-400 hover:text-white hover:bg-white/5 transition-all text-sm font-medium">
          <HelpCircle className="w-5 h-5 text-neutral-500" />
          <span>Support</span>
        </button>
        <button 
          onClick={() => setActiveTab('account')}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-neutral-400 hover:text-white hover:bg-white/5 transition-all text-sm font-medium"
        >
          <Settings className="w-5 h-5 text-neutral-500" />
          <span>Settings</span>
        </button>
      </div>

      {/* User Profile Footer */}
      <div className="p-4 mt-2">
        <div className="flex items-center justify-between p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors border border-white/5 cursor-pointer">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-10 h-10 rounded-full bg-neutral-800 border border-neutral-700 overflow-hidden shrink-0">
              {auth.currentUser?.photoURL ? (
                <img src={auth.currentUser.photoURL} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-neutral-500">
                  <User className="w-5 h-5" />
                </div>
              )}
            </div>
            <div className="flex flex-col truncate">
              <span className="text-sm font-bold truncate text-white">{auth.currentUser?.displayName || 'User'}</span>
              <span className="text-xs text-neutral-400 truncate">{auth.currentUser?.email || 'Guest'}</span>
            </div>
          </div>
          <button 
            onClick={(e) => { e.stopPropagation(); auth.signOut(); }}
            className="text-neutral-500 hover:text-red-400 transition-colors shrink-0 p-1"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
