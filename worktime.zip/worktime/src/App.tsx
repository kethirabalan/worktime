import React, { useState, useEffect } from 'react';
import { db, auth } from './lib/firebase';
import { collection, query, where, onSnapshot, addDoc } from 'firebase/firestore';
import AuthWall from './components/AuthWall';
import Sidebar from './components/Sidebar';
import KanbanBoard from './components/KanbanBoard';
import Chat from './components/Chat';
import Dashboard from './components/Dashboard';
import Timeline from './components/Timeline';
import Account from './components/Account';
import Projects from './components/Projects';
import { Workspace } from './types';
import { Loader2 } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [workspaces, setWorkspaces] = useState<Workspace[]>([]);
  const [activeWorkspaceId, setActiveWorkspaceId] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    return auth.onAuthStateChanged(async (u) => {
      if (u) {
        const q = query(
          collection(db, 'workspaces'),
          where('ownerId', '==', u.uid)
        );

        const unsubscribe = onSnapshot(q, async (snapshot) => {
          const wsList = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
          })) as Workspace[];

          if (wsList.length === 0) {
            // Create default workspace for new user
            const newWs = await addDoc(collection(db, 'workspaces'), {
              name: 'My Workspace',
              ownerId: u.uid,
              createdAt: new Date().toISOString()
            });
            setActiveWorkspaceId(newWs.id);
          } else {
            setWorkspaces(wsList);
            if (!activeWorkspaceId) {
              setActiveWorkspaceId(wsList[0].id);
            }
          }
          setLoading(false);
        });
        return unsubscribe;
      } else {
        setLoading(false);
      }
    });
  }, [activeWorkspaceId]);

  if (loading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-brand-primary">
        <Loader2 className="w-8 h-8 animate-spin text-white" />
      </div>
    );
  }

  return (
    <AuthWall>
      <div className="flex bg-brand-primary h-screen overflow-hidden">
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          workspaces={workspaces}
          activeWorkspaceId={activeWorkspaceId}
          setActiveWorkspaceId={setActiveWorkspaceId}
        />

        <main className="flex-1 overflow-hidden relative flex">
          {activeTab === 'dashboard' && <Dashboard workspaceId={activeWorkspaceId} />}
          {activeTab === 'projects' && <Projects workspaceId={activeWorkspaceId} />}
          {activeTab === 'tasks' && <KanbanBoard workspaceId={activeWorkspaceId} />}
          {activeTab === 'chat' && <Chat workspaceId={activeWorkspaceId} />}
          {activeTab === 'timeline' && <Timeline workspaceId={activeWorkspaceId} />}
          {activeTab === 'account' && <Account />}
        </main>
      </div>
    </AuthWall>
  );
}

