import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Search, 
  MoreVertical, 
  Calendar, 
  Trash2,
  Check,
  ChevronRight,
  User,
  Filter
} from 'lucide-react';
import { db } from '../lib/firebase';
import { collection, query, onSnapshot, addDoc, updateDoc, doc, deleteDoc } from 'firebase/firestore';
import { Task, TaskStatus } from '../types';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface KanbanBoardProps {
  workspaceId: string;
}

const COLUMNS: { id: TaskStatus; label: string; color: string }[] = [
  { id: 'TODO', label: 'To Do', color: 'bg-slate-100' },
  { id: 'IN_PROGRESS', label: 'In Progress', color: 'bg-blue-500' },
  { id: 'DONE', label: 'Completed', color: 'bg-emerald-500' },
];

export default function KanbanBoard({ workspaceId }: KanbanBoardProps) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [addingToColumn, setAddingToColumn] = useState<TaskStatus | null>(null);

  useEffect(() => {
    if (!workspaceId) return;
    const q = query(collection(db, 'workspaces', workspaceId, 'tasks'));
    return onSnapshot(q, (snapshot) => {
      setTasks(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Task)));
    });
  }, [workspaceId]);

  const addTask = async (e: React.FormEvent, status: TaskStatus) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;

    try {
      await addDoc(collection(db, 'workspaces', workspaceId, 'tasks'), {
        workspaceId,
        projectId: 'default',
        title: newTaskTitle,
        status,
        priority: 'MEDIUM',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
      setNewTaskTitle('');
      setAddingToColumn(null);
    } catch (e) {
      console.error(e);
    }
  };

  const updateStatus = async (taskId: string, newStatus: TaskStatus) => {
    try {
      await updateDoc(doc(db, 'workspaces', workspaceId, 'tasks', taskId), {
        status: newStatus,
        updatedAt: new Date().toISOString()
      });
    } catch (e) {
      console.error(e);
    }
  };

  const deleteTask = async (taskId: string) => {
    if (!confirm('Delete task?')) return;
    try {
      await deleteDoc(doc(db, 'workspaces', workspaceId, 'tasks', taskId));
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#f9fafc] text-slate-800 overflow-hidden">
      
      {/* Header */}
      <header className="h-24 px-8 border-b border-slate-200 flex items-center justify-between bg-white shrink-0">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">
            Projects <ChevronRight className="w-3 h-3" /> Marketing App
          </div>
          <h1 className="text-2xl font-bold text-slate-900">Task Board</h1>
        </div>
        
        <div className="flex items-center gap-4">
           <div className="flex -space-x-2 mr-4">
              {[1, 2, 3].map(i => (
                <img key={i} src={`https://i.pravatar.cc/100?img=${i+10}`} className="w-9 h-9 rounded-full border-2 border-white object-cover" alt="User" />
              ))}
              <div className="w-9 h-9 rounded-full bg-slate-100 border-2 border-white flex items-center justify-center text-xs font-bold text-slate-500">+4</div>
           </div>
           <button className="p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors text-slate-500">
              <Filter className="w-5 h-5" />
           </button>
           <button className="bg-[#ea1c57] text-white px-6 py-2.5 rounded-xl font-bold text-sm hover:bg-[#d6184e] transition-colors shadow-lg shadow-red-500/20">
              Share Board
           </button>
        </div>
      </header>

      {/* Kanban Content */}
      <div className="flex-1 p-8 flex gap-8 overflow-x-auto custom-scrollbar">
        {COLUMNS.map(col => (
          <div key={col.id} className="w-96 shrink-0 flex flex-col h-full">
            <div className="flex items-center justify-between mb-6 px-1">
               <div className="flex items-center gap-3">
                  <div className={cn("w-2 h-2 rounded-full", col.color)} />
                  <h3 className="font-bold text-slate-900">{col.label}</h3>
                  <span className="text-xs font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-md">{tasks.filter(t => t.status === col.id).length}</span>
               </div>
               <button onClick={() => setAddingToColumn(col.id)} className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-200 hover:text-slate-600 transition-all">
                  <Plus className="w-5 h-5" />
               </button>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar space-y-4 pr-1">
               <AnimatePresence mode="popLayout">
                 {addingToColumn === col.id && (
                   <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }} className="bg-white p-4 rounded-[2rem] border-2 border-[#ea1c57]/20 shadow-sm">
                      <form onSubmit={(e) => addTask(e, col.id)}>
                        <input 
                          autoFocus
                          type="text" 
                          placeholder="What needs to be done?"
                          value={newTaskTitle}
                          onChange={(e) => setNewTaskTitle(e.target.value)}
                          className="w-full bg-transparent border-none outline-none text-sm font-medium mb-4"
                        />
                        <div className="flex justify-end gap-2">
                           <button type="button" onClick={() => setAddingToColumn(null)} className="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-400 hover:bg-slate-50">Cancel</button>
                           <button type="submit" className="px-4 py-1.5 rounded-lg text-xs font-bold bg-[#ea1c57] text-white">Add Task</button>
                        </div>
                      </form>
                   </motion.div>
                 )}

                 {tasks.filter(t => t.status === col.id).map((task) => (
                   <motion.div
                     key={task.id}
                     layout
                     initial={{ opacity: 0, scale: 0.95 }}
                     animate={{ opacity: 1, scale: 1 }}
                     exit={{ opacity: 0, scale: 0.95 }}
                     className="bg-white p-6 rounded-[2.5rem] border border-slate-200 shadow-sm hover:shadow-md transition-all group cursor-grab active:cursor-grabbing"
                   >
                     <div className="flex items-center justify-between mb-4">
                        <span className={cn(
                          "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                          task.priority === 'HIGH' ? "bg-red-50 text-red-600" : "bg-slate-50 text-slate-500"
                        )}>
                          {task.priority}
                        </span>
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                           <button onClick={() => deleteTask(task.id)} className="p-1.5 text-slate-300 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button>
                           <button className="p-1.5 text-slate-300 hover:text-slate-600 transition-colors"><MoreVertical className="w-4 h-4" /></button>
                        </div>
                     </div>
                     
                     <h4 className="font-bold text-slate-900 mb-6 leading-tight">{task.title}</h4>
                     
                     <div className="flex items-center justify-between pt-6 border-t border-slate-50">
                        <div className="flex items-center gap-4 text-slate-400">
                           <div className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-widest"><Calendar className="w-3.5 h-3.5" /> Today</div>
                        </div>
                        <div className="flex items-center gap-2">
                           {col.id !== 'DONE' ? (
                             <button onClick={() => updateStatus(task.id, 'DONE')} className="w-7 h-7 rounded-full border border-slate-200 flex items-center justify-center hover:bg-emerald-50 hover:border-emerald-200 hover:text-emerald-500 transition-all">
                                <Check className="w-3.5 h-3.5" />
                             </button>
                           ) : (
                             <div className="w-7 h-7 rounded-full bg-emerald-50 text-emerald-500 flex items-center justify-center">
                                <Check className="w-3.5 h-3.5 font-bold" />
                             </div>
                           )}
                           <img src={`https://i.pravatar.cc/100?u=${task.id}`} className="w-7 h-7 rounded-full border border-white" alt="Assigned" />
                        </div>
                     </div>
                   </motion.div>
                 ))}
               </AnimatePresence>
               
               {tasks.filter(t => t.status === col.id).length === 0 && !addingToColumn && (
                 <div className="h-32 border-2 border-dashed border-slate-200 rounded-[2.5rem] flex items-center justify-center">
                    <button onClick={() => setAddingToColumn(col.id)} className="text-sm font-bold text-slate-400 hover:text-[#ea1c57] transition-colors">+ Add your first task</button>
                 </div>
               )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
